#include <stdint.h>
#include <string.h>
#include<stdlib.h>
#include <stdio.h>

/*C'est le programme de l'exercise 2 en suivant les instrctions de l'exercise 2*/

int main(int arg, char **argv)
{
    //Afffichage Of "Hello world"
    //It requires the stdio library
    printf("Hellow world!\n");

    return 0;
}
